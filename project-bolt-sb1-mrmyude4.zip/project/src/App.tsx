import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import ServicesCarousel from './components/ServicesCarousel';
import About from './components/About';
import Reviews from './components/Reviews';
import ContactSection from './components/ContactSection';
import Footer from './components/Footer';
import LogoAnimation from './components/LogoAnimation';
import ServiceWorkPage from './components/ServiceWorkPage';

function App() {
  return (
    <Router>
      <div className="font-sans">
        <LogoAnimation />
        <Navbar />
        <Routes>
          <Route path="/" element={
            <>
              <Hero />
              <ServicesCarousel />
              <About />
              <Reviews />
              <ContactSection />
            </>
          } />
          <Route path="/work/:service" element={<ServiceWorkPage />} />
        </Routes>
        <Footer />
      </div>
    </Router>
  );
}

export default App;