import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { services } from '../data/services';
import { portfolioItems } from '../data/portfolio';
import { ArrowLeft, ExternalLink } from 'lucide-react';

const ServiceWorkPage: React.FC = () => {
  const { service } = useParams();
  const [isVisible, setIsVisible] = useState(false);
  
  const currentService = services.find(s => s.link === `/work/${service}`);
  const servicePortfolio = portfolioItems.filter(item => item.serviceType === service);

  useEffect(() => {
    setIsVisible(true);
    window.scrollTo(0, 0);
  }, []);

  if (!currentService) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-xl text-gray-600">Service not found</p>
      </div>
    );
  }

  return (
    <div className="pt-20">
      <div className="bg-black text-white py-20">
        <div className="container mx-auto px-4">
          <Link 
            to="/" 
            className="inline-flex items-center text-[#b8a369] hover:text-white mb-6 transition-colors duration-200"
          >
            <ArrowLeft size={20} className="mr-2" />
            Back to Home
          </Link>
          <h1 className="text-4xl md:text-5xl font-serif font-bold mb-6">{currentService.title}</h1>
          <div className="w-20 h-1 bg-[#b8a369] mb-8"></div>
          <p className="text-xl text-gray-300 max-w-2xl">{currentService.description}</p>
        </div>
      </div>
      
      <div className="py-20 bg-cream">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-serif font-bold mb-12 text-center">Our Work</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {servicePortfolio.map((item, index) => (
              <div
                key={item.id}
                className={`bg-white rounded-lg overflow-hidden shadow-lg transform transition-all duration-500 hover:shadow-xl ${
                  isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
                }`}
                style={{ transitionDelay: `${index * 200}ms` }}
              >
                <div className="aspect-video">
                  <img 
                    src={item.image} 
                    alt={item.title}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                  <p className="text-gray-600 mb-4">{item.description}</p>
                  {item.link && (
                    <a
                      href={item.link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center text-[#b8a369] hover:text-[#a89255] transition-colors duration-200"
                    >
                      View Live <ExternalLink size={16} className="ml-2" />
                    </a>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ServiceWorkPage;