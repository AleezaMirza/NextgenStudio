import React, { useState, useEffect, useRef } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import ServiceCard from './ServiceCard';
import { services } from '../data/services';

const ServicesCarousel: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [showCount, setShowCount] = useState(3);
  const [isVisible, setIsVisible] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  // Responsive adjustment for cards shown
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 640) {
        setShowCount(1);
      } else if (window.innerWidth < 1024) {
        setShowCount(2);
      } else {
        setShowCount(3);
      }
    };

    handleResize(); // Initial call
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Intersection Observer for animation
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => {
      observer.disconnect();
    };
  }, []);

  const prev = () => {
    setCurrentIndex((prevIndex) => 
      prevIndex > 0 ? prevIndex - 1 : services.length - showCount
    );
  };

  const next = () => {
    setCurrentIndex((prevIndex) => 
      prevIndex < services.length - showCount ? prevIndex + 1 : 0
    );
  };

  // Auto-advance carousel
  useEffect(() => {
    if (isPaused) return;
    
    const interval = setInterval(next, 5000);
    return () => clearInterval(interval);
  }, [currentIndex, isPaused]);

  return (
    <section 
      id="services" 
      className="py-20 bg-black text-white"
      ref={sectionRef}
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
    >
      <div className="container mx-auto px-4">
        <div className={`text-center mb-12 transform transition-all duration-1000 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
          <h2 className="text-3xl md:text-4xl font-serif font-bold mb-4">Our Services</h2>
          <div className="w-20 h-1 bg-[#b8a369] mx-auto mb-6"></div>
          <p className="max-w-2xl mx-auto text-gray-300">
            At NextGen Studio, we build your visual identity through our comprehensive creative solutions.
          </p>
        </div>

        <div className={`relative transform transition-all duration-1000 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`} style={{ transitionDelay: '200ms' }}>
          {/* Navigation buttons */}
          <button 
            className="absolute left-0 top-1/2 -translate-y-1/2 z-10 bg-[#1a1a1a] p-3 rounded-full shadow-md text-[#b8a369] hover:bg-[#b8a369] hover:text-black transition-all duration-300"
            onClick={prev}
            aria-label="Previous slide"
          >
            <ChevronLeft size={24} />
          </button>
          
          <button 
            className="absolute right-0 top-1/2 -translate-y-1/2 z-10 bg-[#1a1a1a] p-3 rounded-full shadow-md text-[#b8a369] hover:bg-[#b8a369] hover:text-black transition-all duration-300"
            onClick={next}
            aria-label="Next slide"
          >
            <ChevronRight size={24} />
          </button>

          {/* Carousel container */}
          <div className="overflow-hidden py-8 px-12">
            <div 
              className="flex gap-6 transition-transform duration-500 ease-out"
              style={{ 
                transform: `translateX(-${currentIndex * (100 / showCount)}%)`,
                width: `${(services.length / showCount) * 100}%`
              }}
            >
              {services.map((service, index) => (
                <div 
                  key={service.id} 
                  className="flex-shrink-0"
                  style={{ width: `calc(${100 / showCount}% - 24px)` }}
                >
                  <ServiceCard 
                    service={service} 
                    isActive={index >= currentIndex && index < currentIndex + showCount}
                  />
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Indicator dots */}
        <div className={`flex justify-center mt-8 gap-2 transform transition-all duration-1000 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`} style={{ transitionDelay: '400ms' }}>
          {Array.from({ length: services.length - showCount + 1 }).map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentIndex(index)}
              className={`w-3 h-3 rounded-full transition-all duration-300 ${
                index === currentIndex ? 'bg-[#b8a369] w-6' : 'bg-gray-700 hover:bg-gray-500'
              }`}
              aria-label={`Go to slide ${index + 1}`}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesCarousel;