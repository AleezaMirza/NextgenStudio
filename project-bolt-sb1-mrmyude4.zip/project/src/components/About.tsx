import React, { useEffect, useRef, useState } from 'react';
import { Zap, Shield, Users, Globe } from 'lucide-react';

const About: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  const values = [
    {
      icon: <Zap size={24} className="text-[#b8a369]" />,
      title: "Innovation",
      description: "We stay ahead of trends to deliver cutting-edge creative solutions."
    },
    {
      icon: <Shield size={24} className="text-[#b8a369]" />,
      title: "Quality",
      description: "We maintain high standards in every project, big or small."
    },
    {
      icon: <Users size={24} className="text-[#b8a369]" />,
      title: "Collaboration",
      description: "We work closely with clients to bring their vision to life."
    },
    {
      icon: <Globe size={24} className="text-[#b8a369]" />,
      title: "Impact",
      description: "We create content that connects and drives meaningful engagement."
    }
  ];

  const scrollToReviews = () => {
    const reviewsSection = document.getElementById('reviews');
    if (reviewsSection) {
      window.scrollTo({
        top: reviewsSection.offsetTop - 80,
        behavior: 'smooth'
      });
    }
  };

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => {
      observer.disconnect();
    };
  }, []);

  return (
    <section id="about" className="py-20 bg-[#fafaf8]" ref={sectionRef}>
      <div className="container mx-auto px-4">
        <div className="flex flex-col lg:flex-row gap-12">
          <div className={`lg:w-1/2 transform transition-all duration-1000 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
            <h2 className="text-3xl md:text-4xl font-serif font-bold mb-6">Who We Are</h2>
            <div className="w-20 h-1 bg-[#b8a369] mb-8"></div>
            <p className="text-gray-600 mb-6 leading-relaxed">
              NextGen Studio is a collective of digital creatives passionate about crafting 
              visual stories that resonate. We combine technical expertise with artistic vision 
              to deliver content that stands out in today's crowded digital landscape.
            </p>
            <p className="text-gray-600 mb-8 leading-relaxed">
              Founded on the belief that great design drives meaningful connections, 
              we partner with creators, businesses, and dreamers to elevate their 
              digital presence through thoughtful, strategic creative work.
            </p>
            <button 
              onClick={scrollToReviews}
              className="px-8 py-3 bg-[#b8a369] hover:bg-[#a89255] text-black font-semibold rounded-md transition-all duration-300 transform hover:scale-105"
            >
              Learn More
            </button>
          </div>
          
          <div className="lg:w-1/2">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {values.map((value, index) => (
                <div 
                  key={index} 
                  className={`bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-all duration-500 transform ${
                    isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
                  }`}
                  style={{ transitionDelay: `${index * 150}ms` }}
                >
                  <div className="mb-4">{value.icon}</div>
                  <h3 className="text-xl font-bold mb-2">{value.title}</h3>
                  <p className="text-gray-600">{value.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;