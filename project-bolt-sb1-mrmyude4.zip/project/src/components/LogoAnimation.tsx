import React, { useState, useEffect } from 'react';

const LogoAnimation: React.FC = () => {
  const [loaded, setLoaded] = useState(false);
  const [hidden, setHidden] = useState(false);

  useEffect(() => {
    setLoaded(true);
    const timer = setTimeout(() => {
      setHidden(true);
    }, 2500);

    return () => clearTimeout(timer);
  }, []);

  if (hidden) return null;

  return (
    <div 
      className={`fixed inset-0 z-[9999] flex items-center justify-center bg-black transition-opacity duration-500 ${
        loaded ? 'opacity-0' : 'opacity-100'
      }`}
      style={{ pointerEvents: loaded ? 'none' : 'auto' }}
    >
      <div className="text-center">
        <div className="flex flex-col items-center">
          <div className="mb-2 relative">
            <span className="font-serif font-bold text-5xl text-white opacity-0 animate-[fadeIn_0.5s_ease_forwards_0.3s]">
              NEXTGEN
            </span>
            <div className="absolute top-[-16px] right-[-10px] text-[#b8a369] opacity-0 animate-[fadeIn_0.5s_ease_forwards_0.6s]">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 2L12 22M2 12L22 12M17 7L7 17M7 7L17 17" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
              </svg>
            </div>
          </div>
          <span className="font-sans text-lg tracking-widest text-white opacity-0 animate-[fadeIn_0.5s_ease_forwards_0.9s]">
            STUDIO
          </span>
        </div>
      </div>
    </div>
  );
};

export default LogoAnimation;