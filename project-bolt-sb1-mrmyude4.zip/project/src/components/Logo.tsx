import React from 'react';

interface LogoProps {
  scrolled: boolean;
}

const Logo: React.FC<LogoProps> = ({ scrolled }) => {
  return (
    <div className="flex items-center">
      <div className="flex flex-col items-center">
        <span className={`font-serif font-bold text-2xl transition-colors duration-300 ${scrolled ? 'text-black' : 'text-white'}`}>
          NEXTGEN
        </span>
        <span className={`font-sans text-sm tracking-widest transition-colors duration-300 mt-[-4px] ${scrolled ? 'text-black' : 'text-white'}`}>
          STUDIO
        </span>
      </div>
      <div className={`ml-1 mt-[-16px] transition-colors duration-300 ${scrolled ? 'text-[#b8a369]' : 'text-[#b8a369]'}`}>
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M12 2L12 22M2 12L22 12M17 7L7 17M7 7L17 17" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        </svg>
      </div>
    </div>
  );
};

export default Logo;