import React from 'react';
import * as LucideIcons from 'lucide-react';
import { Service } from '../types';
import { Link } from 'react-router-dom';

interface ServiceCardProps {
  service: Service;
  isActive: boolean;
}

const ServiceCard: React.FC<ServiceCardProps> = ({ service, isActive }) => {
  const IconComponent = LucideIcons[service.icon as keyof typeof LucideIcons];
  
  return (
    <Link 
      to={service.link}
      className={`
        flex flex-col rounded-xl p-6 h-full transition-all duration-500 transform
        ${isActive ? 'scale-100 opacity-100 bg-[#1a1a1a] shadow-xl' : 'scale-95 opacity-60 bg-[#121212]'}
        hover:shadow-[0_0_15px_rgba(184,163,105,0.2)] hover:transform hover:scale-[1.03]
      `}
    >
      <div className={`p-4 rounded-full w-16 h-16 flex items-center justify-center mb-4 ${service.color} text-white`}>
        {IconComponent && <IconComponent size={28} />}
      </div>
      <h3 className="text-xl font-bold mb-2 text-white">{service.title}</h3>
      <p className="text-gray-400">{service.description}</p>
    </Link>
  );
};

export default ServiceCard;