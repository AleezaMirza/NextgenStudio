import React from 'react';
import { Instagram, Twitter, Linkedin, Facebook, Mail } from 'lucide-react';
import Logo from './Logo';

const Footer: React.FC = () => {
  return (
    <footer className="bg-black text-white py-12">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center md:items-start mb-12">
          <div className="mb-8 md:mb-0">
            <div className="flex justify-center md:justify-start">
              <Logo scrolled={true} />
            </div>
            <p className="text-gray-400 max-w-xs mt-4 text-center md:text-left">
              Building visual identities through full-stack creative solutions for creators, businesses, and dreamers.
            </p>
            <div className="flex space-x-4 mt-6 justify-center md:justify-start">
              <a href="#" className="text-gray-400 hover:text-[#b8a369] transition-colors duration-300">
                <Instagram size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-[#b8a369] transition-colors duration-300">
                <Twitter size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-[#b8a369] transition-colors duration-300">
                <Linkedin size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-[#b8a369] transition-colors duration-300">
                <Facebook size={20} />
              </a>
            </div>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-lg font-semibold mb-4 text-[#b8a369]">Company</h3>
              <ul className="space-y-2">
                <li><a href="#about" className="text-gray-400 hover:text-white transition-colors duration-200">About Us</a></li>
                <li><a href="#services" className="text-gray-400 hover:text-white transition-colors duration-200">Services</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors duration-200">Work</a></li>
                <li><a href="#contact" className="text-gray-400 hover:text-white transition-colors duration-200">Contact</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4 text-[#b8a369]">Services</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors duration-200">Graphic Design</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors duration-200">Video Editing</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors duration-200">Photo Editing</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors duration-200">Content Creation</a></li>
              </ul>
            </div>
            
            <div className="col-span-2 md:col-span-1">
              <h3 className="text-lg font-semibold mb-4 text-[#b8a369]">Newsletter</h3>
              <p className="text-gray-400 mb-4">Subscribe to our newsletter for the latest updates and offers.</p>
              <div className="flex">
                <input 
                  type="email" 
                  placeholder="Your email" 
                  className="bg-gray-900 text-white px-4 py-2 rounded-l-md focus:outline-none w-full"
                />
                <button className="bg-[#b8a369] hover:bg-[#a89255] text-black px-4 py-2 rounded-r-md transition-colors duration-200">
                  <Mail size={20} />
                </button>
              </div>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-800 pt-8 mt-8 text-center md:flex md:justify-between md:items-center">
          <p className="text-gray-500">© {new Date().getFullYear()} NextGen Studio. All rights reserved.</p>
          <div className="mt-4 md:mt-0 space-x-6">
            <a href="#" className="text-gray-500 hover:text-white transition-colors duration-200">Privacy Policy</a>
            <a href="#" className="text-gray-500 hover:text-white transition-colors duration-200">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;