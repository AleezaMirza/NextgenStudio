import React from 'react';
import { Mail, Phone, Instagram, MessageSquare } from 'lucide-react';

const ContactSection: React.FC = () => {
  return (
    <section id="contact" className="py-20 bg-neutral-900 text-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Contact Us</h2>
          <div className="w-20 h-1 bg-[#b8a369] mx-auto mb-6"></div>
          <p className="max-w-2xl mx-auto text-gray-300">
            Ready to bring your vision to life? Reach out to us and let's create something amazing together.
          </p>
        </div>

        <div className="flex flex-col lg:flex-row gap-12">
          <div className="lg:w-1/2">
            <form className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-300 mb-2">Your Name</label>
                  <input 
                    type="text" 
                    id="name" 
                    className="w-full px-4 py-3 bg-neutral-800 border border-neutral-700 rounded-md focus:outline-none focus:ring-2 focus:ring-[#b8a369] text-white"
                    placeholder="John Doe"
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-300 mb-2">Email Address</label>
                  <input 
                    type="email" 
                    id="email" 
                    className="w-full px-4 py-3 bg-neutral-800 border border-neutral-700 rounded-md focus:outline-none focus:ring-2 focus:ring-[#b8a369] text-white"
                    placeholder="hello@example.com"
                  />
                </div>
              </div>
              
              <div>
                <label htmlFor="subject" className="block text-sm font-medium text-gray-300 mb-2">Subject</label>
                <input 
                  type="text" 
                  id="subject" 
                  className="w-full px-4 py-3 bg-neutral-800 border border-neutral-700 rounded-md focus:outline-none focus:ring-2 focus:ring-[#b8a369] text-white"
                  placeholder="Project Inquiry"
                />
              </div>
              
              <div>
                <label htmlFor="message" className="block text-sm font-medium text-gray-300 mb-2">Your Message</label>
                <textarea 
                  id="message" 
                  rows={6} 
                  className="w-full px-4 py-3 bg-neutral-800 border border-neutral-700 rounded-md focus:outline-none focus:ring-2 focus:ring-[#b8a369] text-white resize-none"
                  placeholder="Tell us about your project or inquiry..."
                ></textarea>
              </div>
              
              <button type="submit" className="px-8 py-3 bg-[#b8a369] hover:bg-[#a89255] text-black font-semibold rounded-md transition-all duration-200 transform hover:scale-105 w-full md:w-auto">
                Send Message
              </button>
            </form>
          </div>
          
          <div className="lg:w-1/2 flex flex-col justify-between">
            <div className="space-y-8">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-neutral-800 rounded-full">
                  <Mail size={24} className="text-[#b8a369]" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">Email Us</h3>
                  <p className="text-gray-300">hello@nextgenstudio.com</p>
                </div>
              </div>
              
              <div className="flex items-start gap-4">
                <div className="p-3 bg-neutral-800 rounded-full">
                  <Phone size={24} className="text-[#b8a369]" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">Call/WhatsApp</h3>
                  <p className="text-gray-300">+91 9920081598</p>
                  <p className="text-gray-300">+91 9819367135</p>
                </div>
              </div>
            </div>
            
            <div className="mt-8 lg:mt-0">
              <h3 className="text-xl font-semibold mb-4">Connect With Us</h3>
              <div className="flex gap-4">
                <a 
                  href="https://www.instagram.com/_nextgenstudio_/" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="p-3 bg-neutral-800 rounded-full hover:bg-[#b8a369] hover:text-black transition-all duration-200"
                >
                  <Instagram size={24} />
                </a>
                <a 
                  href="https://wa.me/919920081598" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="p-3 bg-neutral-800 rounded-full hover:bg-[#b8a369] hover:text-black transition-all duration-200"
                >
                  <MessageSquare size={24} />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;