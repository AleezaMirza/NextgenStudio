import React, { useEffect, useState } from 'react';
import { ArrowDown } from 'lucide-react';

const Hero: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const scrollToServices = () => {
    const servicesSection = document.getElementById('services');
    if (servicesSection) {
      window.scrollTo({
        top: servicesSection.offsetTop - 80,
        behavior: 'smooth'
      });
    }
  };

  const scrollToContact = () => {
    const contactSection = document.getElementById('contact');
    if (contactSection) {
      window.scrollTo({
        top: contactSection.offsetTop - 80,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section id="home" className="relative h-screen flex items-center justify-center overflow-hidden">
      {/* Background with overlay gradient */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat z-0"
        style={{ 
          backgroundImage: "url('https://images.pexels.com/photos/3182835/pexels-photo-3182835.jpeg?auto=compress&cs=tinysrgb&w=1600')",
          filter: "brightness(0.6)" 
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-black/80 to-black/70 z-10" />
      
      {/* Content */}
      <div className="container mx-auto px-6 z-20 text-center">
        <div className={`transform transition-all duration-1000 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight">
            <span className="block">Creative Solutions</span>
            <span className="block mt-2">for the Digital Age</span>
          </h1>
          <p className="text-xl md:text-2xl text-gray-200 mb-8 max-w-3xl mx-auto">
            We don't just deliver services — we build your visual identity.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <button 
              onClick={scrollToServices}
              className="px-8 py-3 bg-[#b8a369] hover:bg-[#a89255] text-black font-semibold rounded-md transition-all duration-300 transform hover:scale-105"
            >
              Our Services
            </button>
            <button 
              onClick={scrollToContact}
              className="px-8 py-3 bg-transparent hover:bg-white/10 text-white font-semibold rounded-md border border-white transition-all duration-300"
            >
              Get in Touch
            </button>
          </div>
        </div>
        
        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
          <ArrowDown 
            size={24}
            className="text-white"
            onClick={scrollToServices}
          />
        </div>
      </div>
    </section>
  );
};

export default Hero;