import { PortfolioItem } from '../types';

export const portfolioItems: PortfolioItem[] = [
  // Graphic Design
  {
    id: 1,
    title: "Brand Identity Package",
    description: "Complete brand identity design including logo, color palette, and typography",
    image: "https://images.pexels.com/photos/1037992/pexels-photo-1037992.jpeg?auto=compress&cs=tinysrgb&w=1600",
    serviceType: "graphic-design"
  },
  {
    id: 2,
    title: "Marketing Materials",
    description: "Print and digital marketing collateral for business growth",
    image: "https://images.pexels.com/photos/5611966/pexels-photo-5611966.jpeg?auto=compress&cs=tinysrgb&w=1600",
    serviceType: "graphic-design"
  },

  // Video Editing
  {
    id: 3,
    title: "Product Launch Video",
    description: "Cinematic product showcase with motion graphics",
    image: "https://images.pexels.com/photos/2608517/pexels-photo-2608517.jpeg?auto=compress&cs=tinysrgb&w=1600",
    serviceType: "video-editing"
  },
  {
    id: 4,
    title: "Social Media Stories",
    description: "Engaging short-form video content for social platforms",
    image: "https://images.pexels.com/photos/18105/pexels-photo.jpg?auto=compress&cs=tinysrgb&w=1600",
    serviceType: "video-editing"
  },

  // Photo Editing
  {
    id: 5,
    title: "Product Photography",
    description: "Professional product photos with advanced retouching",
    image: "https://images.pexels.com/photos/3178938/pexels-photo-3178938.jpeg?auto=compress&cs=tinysrgb&w=1600",
    serviceType: "photo-editing"
  },
  {
    id: 6,
    title: "Portrait Enhancement",
    description: "Natural-looking portrait retouching",
    image: "https://images.pexels.com/photos/3062541/pexels-photo-3062541.jpeg?auto=compress&cs=tinysrgb&w=1600",
    serviceType: "photo-editing"
  },

  // Social Media Management
  {
    id: 7,
    title: "Instagram Growth Campaign",
    description: "Strategic content and engagement planning",
    image: "https://images.pexels.com/photos/607812/pexels-photo-607812.jpeg?auto=compress&cs=tinysrgb&w=1600",
    serviceType: "social-media"
  },
  {
    id: 8,
    title: "Social Media Branding",
    description: "Consistent visual identity across platforms",
    image: "https://images.pexels.com/photos/5053740/pexels-photo-5053740.jpeg?auto=compress&cs=tinysrgb&w=1600",
    serviceType: "social-media"
  },

  // Content Creation
  {
    id: 9,
    title: "Blog Content Strategy",
    description: "Comprehensive content planning and creation",
    image: "https://images.pexels.com/photos/1591056/pexels-photo-1591056.jpeg?auto=compress&cs=tinysrgb&w=1600",
    serviceType: "content-creation"
  },
  {
    id: 10,
    title: "Visual Storytelling",
    description: "Engaging visual narratives for brands",
    image: "https://images.pexels.com/photos/3182746/pexels-photo-3182746.jpeg?auto=compress&cs=tinysrgb&w=1600",
    serviceType: "content-creation"
  },

  // Thumbnail & Logo Design
  {
    id: 11,
    title: "YouTube Channel Branding",
    description: "Consistent thumbnail design system",
    image: "https://images.pexels.com/photos/1779487/pexels-photo-1779487.jpeg?auto=compress&cs=tinysrgb&w=1600",
    serviceType: "thumbnail-logo"
  },
  {
    id: 12,
    title: "Modern Logo Collection",
    description: "Minimalist and memorable logo designs",
    image: "https://images.pexels.com/photos/6444/pencil-typography-black-design.jpg?auto=compress&cs=tinysrgb&w=1600",
    serviceType: "thumbnail-logo"
  },

  // Website Building
  {
    id: 13,
    title: "E-commerce Website",
    description: "Modern online store with seamless checkout",
    image: "https://images.pexels.com/photos/39284/macbook-apple-imac-computer-39284.jpeg?auto=compress&cs=tinysrgb&w=1600",
    serviceType: "website-building",
    link: "https://example-store.com"
  },
  {
    id: 14,
    title: "Portfolio Website",
    description: "Creative portfolio with smooth animations",
    image: "https://images.pexels.com/photos/196644/pexels-photo-196644.jpeg?auto=compress&cs=tinysrgb&w=1600",
    serviceType: "website-building",
    link: "https://example-portfolio.com"
  }
];