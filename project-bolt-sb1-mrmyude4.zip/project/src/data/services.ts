import { Service } from '../types';

export const services: Service[] = [
  {
    id: 1,
    title: "Graphic Design",
    icon: "Palette",
    description: "Minimal, modern, and memorable designs that capture your brand's essence.",
    color: "bg-[#b8a369]",
    link: "/work/graphic-design"
  },
  {
    id: 2,
    title: "Video Editing",
    icon: "Video",
    description: "Short-form, cinematic, or viral-ready videos that engage your audience.",
    color: "bg-[#b8a369]",
    link: "/work/video-editing"
  },
  {
    id: 3,
    title: "Photo Editing",
    icon: "Image",
    description: "Retouching that looks natural & clean, enhancing your visual content.",
    color: "bg-[#b8a369]",
    link: "/work/photo-editing"
  },
  {
    id: 4,
    title: "Social Media Management",
    icon: "Instagram",
    description: "Content, captions, and consistency to build your online presence.",
    color: "bg-[#b8a369]",
    link: "/work/social-media"
  },
  {
    id: 5,
    title: "Content Creation",
    icon: "Pencil",
    description: "From ideas to visuals, we transform concepts into compelling content.",
    color: "bg-[#b8a369]",
    link: "/work/content-creation"
  },
  {
    id: 6,
    title: "Thumbnail & Logo Design",
    icon: "Layout",
    description: "Your brand, leveled up with eye-catching thumbnails and logos.",
    color: "bg-[#b8a369]",
    link: "/work/thumbnail-logo"
  },
  {
    id: 7,
    title: "Website Building",
    icon: "Globe2",
    description: "Modern, responsive websites that elevate your digital presence.",
    color: "bg-[#b8a369]",
    link: "/work/website-building"
  }
];