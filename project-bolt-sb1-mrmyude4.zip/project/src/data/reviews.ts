import { Review } from '../types';

export const reviews: Review[] = [
  {
    id: 1,
    name: "Sarah Johnson",
    role: "Content Creator",
    content: "NextGen Studio transformed my brand identity. Their attention to detail and creative vision exceeded my expectations!",
    image: "https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    rating: 5
  },
  {
    id: 2,
    name: "David Chen",
    role: "Business Owner",
    content: "The team's professionalism and creativity helped our business stand out. They delivered beyond our expectations!",
    image: "https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    rating: 5
  },
  {
    id: 3,
    name: "Emily Rodriguez",
    role: "Digital Marketer",
    content: "Working with NextGen Studio was a game-changer for our social media presence. Their content strategy drove real results.",
    image: "https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    rating: 5
  }
];