export interface Service {
  id: number;
  title: string;
  icon: string;
  description: string;
  color: string;
  link: string;
}

export interface Review {
  id: number;
  name: string;
  role: string;
  content: string;
  image: string;
  rating: number;
}

export interface PortfolioItem {
  id: number;
  title: string;
  description: string;
  image: string;
  serviceType: string;
  link?: string;
}